var axios = require('axios');
var fs = require('file-system');
let records = [];

(async () => {

    let results = [];
    fs.readFile('/home/wolborg/asd/response.json', (err, data) => {
        if (err) throw err;

        records = JSON.parse(data);
         //console.log(records.length);

        for (let i of records) {
            (async () => {
                results = records.splice(0, 100);
                //console.log(results.length);
                await axios({
                    method: 'POST',
                    url: 'https://manage.searchtap.net/v2/collections/2YG26KYLJRXBJ67T575CB3UY/records',
                    headers: {'Authorization': 'Bearer SJL7R1GQY4ACK4ZEN4JI94T4'},
                    data: results
                })
                    .then(function (res) {
                        // console.log(res.data);
                        console.log(res.status);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
            })();
        }
    });
    // for(let i =1; i<=5; i++ ) {
    //
    //   ///  let response = await axios.get(`https://api.punkapi.com/v2/beers/?page=${i}&per_page=50`);
    //
    //     console.log('page number: ', i);
    //     results = results.concat(response.data);
    // }
    // console.log(records.length);
    // let response = await axios.post(`https://manage.searchtap.net/v2/collections/2YG26KYLJRXBJ67T575CB3UY/records`);
})();











